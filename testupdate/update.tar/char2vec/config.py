import os

CUR_TO_DATASET_PATH = '../dataset/'
BENIGN_PATH = os.path.join(CUR_TO_DATASET_PATH, 'benigns.csv')
PHISHING_PATH = os.path.join(CUR_TO_DATASET_PATH, 'phishings.csv')
MODEL_SAVE_PATH = os.path.join(CUR_TO_DATASET_PATH, 'model/char2vec.cv')

